import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-dailog',
  templateUrl: './dailog.component.html',
  styleUrls: ['./dailog.component.css']
})

export class DailogComponent {

  constructor(public dialogRef: MatDialogRef<DailogComponent>, @Inject(MAT_DIALOG_DATA) public data: DialogData) {
    }

  onNoClick(): void {
    console.log('onNoClick');
    this.dialogRef.close();
  }

  onCloseConfirm() {
    this.dialogRef.close('Confirm');
  }
  onCloseCancel() {
    this.dialogRef.close('Cancel');
  }

}

export interface DialogData {
  comments: string;
}