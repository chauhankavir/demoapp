import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';

import { DailogComponent } from '../dialog/dailog/dailog.component';
import { ApiProvider } from '../taskservice';


@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  displayedColumns: string[] = ['ToDoTask','Actions'];
  dataSource: MatTableDataSource<any>;
  comment: string; 
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dolist: any; 

  constructor(private apiProvider: ApiProvider,private dialog: MatDialog, private router: Router) { 
   this.TaskData();
  }

  ngOnInit() {
  }

  AddTask(){
    this.router.navigateByUrl('/add');
  }

  TaskData(){
    this.dolist=this.apiProvider.GetTask();
    this.dataSource=this.dolist;
  }


  DeleteTask(task: string) {
    // if(this.dolist.length==1)
    // this.AddTask();
    this.apiProvider.DeleteTask(task);
    this.TaskData();
  }

  openDialog(task: string): void {
    const dialogRef = this.dialog.open(DailogComponent, {
      width: '300px', 
      data: {comments: this.comment}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.comment = result;
     if(this.comment != undefined){
      if(this.comment.trim()=="Confirm")
      this.DeleteTask(task);
     }
    });
  }

}
