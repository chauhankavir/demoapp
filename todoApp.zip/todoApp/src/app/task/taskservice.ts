import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';

@Injectable()
export class ApiProvider {
data: any; pushData: any;
dataArray: Array<string>=[];

constructor() {
}

GetTask(){
  this.data=localStorage.getItem("data");
  if(!isNullOrUndefined(this.data))
  this.dataArray = this.data.split(",");
  return this.dataArray;
}

PostTask(task: string) {
  this.ConvertStringToArray();
  this.dataArray.push(task);
  localStorage.setItem('data',this.dataArray.toString());
}

DeleteTask(task: string) {
  this.ConvertStringToArray();
  let index: number = this.dataArray.indexOf(task);
  if (index !== -1) {
    this.dataArray.splice(index, 1);
  } 

  if(this.dataArray.length==0)
  localStorage.removeItem('data');
  else
  localStorage.setItem('data',this.dataArray.toString());
}

ConvertStringToArray(){
  this.data=localStorage.getItem("data");
  if(!isNullOrUndefined(this.data))
  this.dataArray = this.data.split(",");
}

}