import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatSnackBarModule } from '@angular/material';
import { FormsModule } from '@angular/forms';

import { MaterialModule } from './../core/material.module';
import { ListComponent } from './list/list.component';
import { InputComponent } from './input/input.component';
import { DailogComponent } from './dialog/dailog/dailog.component';
import { ApiProvider } from './taskservice';

@NgModule({
  declarations: [
    InputComponent, 
    ListComponent,
    DailogComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatSnackBarModule,
    MaterialModule,
    RouterModule.forChild(
      [ 
          { path: 'add', component: InputComponent },
          { path: 'details', component: ListComponent }
      ]
    )
  ],
  providers: [ApiProvider],
  entryComponents: [DailogComponent]

})
export class TaskModule { }
