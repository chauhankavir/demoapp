import { Component, OnInit } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { Router } from '@angular/router';

import { SnackbarService } from '../../shared/snackbar.service';
import { ApiProvider } from '../taskservice';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class InputComponent implements OnInit {
  task: string=null;
  constructor(private snackbarService: SnackbarService, private serviceProvider: ApiProvider, private router: Router) { }

  ngOnInit() {

  }

  Add(){
    if(isNullOrUndefined(this.task) || this.task==''){
      this.snackbarService.openSnackBar('Note:','Please provide task name',3000);
    }
    else{
    this.serviceProvider.PostTask(this.task);
    this.task=null;
    this.snackbarService.openSnackBar('Note:','To-Do Task added successfully.',3000);
    }
  }

  ReviewTask(){
 this.router.navigateByUrl('/details')
  }

}
